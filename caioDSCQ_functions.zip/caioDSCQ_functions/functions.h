int getPentagonalNumber(int n);
void Question1();