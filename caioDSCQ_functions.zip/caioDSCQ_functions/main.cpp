#include "functions.h"
#include <iostream>
using namespace std;

int main() {

  Question1();

  return 0;
}