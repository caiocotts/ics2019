#include <iomanip>
#include <iostream>

using namespace std;

int getPentagonalNumber(int n) {

  int p = n * (3 * n - 1) / 2;
  return p;
}
void Question1() {
  for (int x = 1; x <= 50; x++) {
    int p = getPentagonalNumber(x);
    if (x % 5 == 0)
      cout << setw(8) << p << endl;
    else
      cout << setw(8) << p;
  }
}